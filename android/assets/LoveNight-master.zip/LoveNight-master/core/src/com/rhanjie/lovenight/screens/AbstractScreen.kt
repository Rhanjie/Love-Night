package com.rhanjie.lovenight.screens

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.Screen
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.scenes.scene2d.Stage
import com.badlogic.gdx.utils.viewport.ScreenViewport
import com.rhanjie.lovenight.MainClass


abstract class AbstractScreen constructor(val game: MainClass): Screen {
    protected var stage: Stage

    protected var spriteBatch: SpriteBatch
    private lateinit var camera: OrthographicCamera


    init {
        this.createCamera()

        stage = Stage(ScreenViewport(camera))
        spriteBatch = SpriteBatch()

        (Gdx.input).inputProcessor = stage
    }

    override fun render(delta: Float) {
        camera.update()

        spriteBatch.projectionMatrix = camera.combined

        (Gdx.gl).glClearColor(0.2F, 0.6F, 1F, 1F)
        (Gdx.gl).glClear(GL20.GL_COLOR_BUFFER_BIT)
    }

    override fun resize(width: Int, height: Int) {
        //...
    }

    override fun resume() {
        MainClass.paused = false
    }

    override fun pause() {
        MainClass.paused = true
    }

    override fun dispose() {
        //...

        game.dispose()
    }

    override fun show() {
        //...
    }

    override fun hide() {
        //...
    }

    private fun createCamera() {
        camera = OrthographicCamera()
        camera.setToOrtho(false)

        camera.update()
    }
}