package com.rhanjie.lovenight

import com.badlogic.gdx.Game
import com.rhanjie.lovenight.screens.GameplayScreen
import java.util.*

fun ClosedRange<Int>.random() = Random().nextInt(endInclusive - start) + start /** (1..5).random() **/

class MainClass : Game() {
    companion object {
        //TODO - Loading config from file.

        /*var windowName: String = "LibGDX Game"
        var windowSize: Vector2 = Vector2(1024F, 768F)*/

        var paused: Boolean = false
    }

    override fun create() {
        this.setScreen(GameplayScreen(this))

        //...
    }
}
