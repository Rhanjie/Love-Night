package com.rhanjie.lovenight.world.tools

class MapData {
    lateinit var name: String
    lateinit var array: Array<Array<Array<Int?>>>
}