package com.rhanjie.lovenight.input

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.input.GestureDetector.GestureListener
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.scenes.scene2d.Stage
import com.rhanjie.lovenight.entities.Player
import com.rhanjie.lovenight.world.Terrain
import com.rhanjie.lovenight.world.tools.TileType

class MyGestureListener constructor(private val player: Player, private val camera: OrthographicCamera, private val gameMap: Terrain) : GestureListener{
    private var currentScale: Float = camera.zoom
    private var oldZoom: Float      = camera.zoom


    /** Generate map **/
    override fun tap(x: Float, y: Float, count: Int, button: Int): Boolean{
        //val position: Vector3 = camera.unproject(Vector3(x, y, 0F))
        //val type: TileType? = gameMap.getTileByLocation(1, position.x, position.y)

        if(count >= 2) {
            if(camera.zoom <= 0.6F){
                oldZoom = camera.zoom
                camera.zoom = 1.0F //TODO: Add interpolate

                camera.update()
                return true
            }

            camera.zoom = oldZoom

            camera.update()
            return true
        }

        return false
    }

    /** Moving camera **/
    override fun pan(x: Float, y: Float, deltaX: Float, deltaY: Float): Boolean{
        camera.translate(-deltaX * currentScale, deltaY * currentScale)

        camera.update()
        return true
    }

    /** Zooming camera **/
    override fun zoom(originalDistance: Float, currentDistance: Float): Boolean{
        if(camera.zoom < 1.0F){
            camera.zoom = currentScale * (originalDistance / currentDistance)

            if (camera.zoom > 0.6F) camera.zoom = 0.6F
            if (camera.zoom < 0.4F) camera.zoom = 0.4F

            camera.update()
            return true
        }

        return false
    }

    /** Reset values **/
    override fun touchDown(x: Float, y: Float, pointer: Int, button: Int): Boolean{
        currentScale = camera.zoom

        return true
    }


    override fun longPress(x: Float, y: Float): Boolean{

        return false
    }

    override fun fling(velocityX: Float, velocityY: Float, button: Int): Boolean{

        return false
    }

    override fun panStop(x: Float, y: Float, pointer: Int, button: Int): Boolean {

        return false
    }

    override fun pinch(initialFirstPointer: Vector2, initialSecondPointer: Vector2, firstPointer: Vector2, secondPointer: Vector2): Boolean{

        return false
    }

    override fun pinchStop() {}
}