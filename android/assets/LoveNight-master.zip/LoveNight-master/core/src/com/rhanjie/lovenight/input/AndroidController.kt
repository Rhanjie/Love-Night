package com.rhanjie.lovenight.input

import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.scenes.scene2d.InputEvent
import com.badlogic.gdx.scenes.scene2d.InputListener
import com.badlogic.gdx.scenes.scene2d.Stage
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Table


class AndroidController constructor(stage: Stage) {
    private val UI_SIZE: Float = 120F

    var isUpPressed: Boolean = false
    var isDownPressed: Boolean = false
    var isRightPressed: Boolean = false
    var isLeftPressed: Boolean = false

    init { //TODO: Need refactor - ugly code
        val upImg = Image(Texture("HUD/controller_up.png"))
        upImg.setSize(UI_SIZE, UI_SIZE)
        upImg.addListener(object: InputListener(){
            override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
                isUpPressed = true

                return true
            }

            override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
                isUpPressed = false
            }
        })

        val downImg = Image(Texture("HUD/controller_down.png"))
        downImg.setSize(UI_SIZE, UI_SIZE)
        downImg.addListener(object: InputListener(){
            override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
                isDownPressed = true

                return true
            }

            override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
                isDownPressed = false
            }
        })

        val rightImg = Image(Texture("HUD/controller_right.png"))
        rightImg.setSize(UI_SIZE, UI_SIZE)
        rightImg.addListener(object: InputListener(){
            override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
                isRightPressed = true

                return true
            }

            override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
                isRightPressed = false
            }
        })

        val leftImg = Image(Texture("HUD/controller_left.png"))
        leftImg.setSize(UI_SIZE, UI_SIZE)
        leftImg.addListener(object: InputListener(){
            override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
                isLeftPressed = true

                return true
            }

            override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
                isLeftPressed = false
            }
        })

        val table = Table()
            table.left().bottom()
                table.add()
                table.add(upImg).size(upImg.width, upImg.height)
                table.add()
            table.row().pad(5F, 5F, 5F, 5F)
                table.add(leftImg).size(leftImg.width, leftImg.height)
                table.add()
                table.add(rightImg).size(rightImg.width, rightImg.height)
            table.row().padBottom(5f)
                table.add()
                table.add(downImg).size(downImg.width, downImg.height)
                table.add()
        stage.addActor(table)
    }
}