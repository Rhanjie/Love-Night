package com.rhanjie.lovenight.world

import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.math.Vector2
import com.rhanjie.lovenight.world.tools.TileType

abstract class AbstractMap {
    companion object { //TODO: Loading data from file
        val LAYERS: Int = 3
        val WIDTH:  Int = 200
        val HEIGHT: Int = 100
    }

    protected val batch: SpriteBatch = SpriteBatch()
    protected lateinit var name: String

    protected lateinit var array: Array<Array<Array<Int?>>>
    protected lateinit var tiles: Array<Array<TextureRegion>>
    protected lateinit var tilesBack: Array<Array<TextureRegion>>


    abstract fun update(delta : Float)
    abstract fun render(camera : OrthographicCamera)
    abstract fun dispose()

    fun getTileByLocation(layer: Int, x: Float, y: Float): TileType?{
        return this.getTileByCoordinate(layer, x.toInt() / TileType.TILESIZE,y.toInt() / TileType.TILESIZE)
    }

    abstract fun getTileByCoordinate(layer: Int, x: Int, y: Int): TileType?

    abstract fun getSize(): Vector2
    abstract fun getLayers(): Int
}