package com.rhanjie.lovenight.world

import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.math.Vector2
import com.rhanjie.lovenight.world.tools.MapData
import com.rhanjie.lovenight.world.tools.TileType

class Terrain constructor(name: String): AbstractMap() {

    init {
        this.changeMap(name)

        tiles = TextureRegion.split(Texture("tiles.png"), TileType.TILESIZE, TileType.TILESIZE)
        tilesBack = TextureRegion.split(Texture("tiles_back.png"), TileType.TILESIZE, TileType.TILESIZE)
    }

    fun changeMap(name: String){
        val data: MapData = MapLoader.generateRandomMap(name)
        //val data: MapData = MapLoader.load(name) //TODO: Problem with emulator

        this.name  = data.name
        this.array = data.array
    }

    override fun update(delta: Float) {
        TODO("not implemented")
    }

    override fun render(camera: OrthographicCamera) {
        batch.projectionMatrix = camera.combined

        batch.begin().apply {
            for(layer: Int in 0 until AbstractMap.LAYERS) {
                for(y: Int in 0 until AbstractMap.HEIGHT) {
                    for(x: Int in 0 until AbstractMap.WIDTH) {
                        val type: TileType? = getTileByCoordinate(layer, x, y)

                        if(type != null) {
                            when(layer) {
                                0 -> batch.draw(tilesBack[type.id - 1][0], x * (TileType.TILESIZE).toFloat(), y * (TileType.TILESIZE).toFloat())
                                1 -> batch.draw(tiles[type.id - 1][0], x * (TileType.TILESIZE).toFloat(), y * (TileType.TILESIZE).toFloat())
                            }
                        }
                    }
                }
            }

            batch.end()
        }
    }

    override fun dispose() {
        batch.dispose()
    }


    override fun getTileByCoordinate(layer: Int, x: Int, y: Int): TileType? {
        if(x < 0 || x > array[0][0].size-1 || y < 0 || y > array[0].size-1)
            return null

        //[(array[0].size - y) - 1] - because I need rotate the Y axis.
        return TileType.getTileById(array[layer][(array[0].size - y) - 1][x]!!)
    }

    override fun getSize() = Vector2((array[0][0].size).toFloat(), (array[0].size).toFloat())

    override fun getLayers(): Int {
        TODO("not implemented")
    }
}