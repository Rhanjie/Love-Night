package com.rhanjie.lovenight.world.tools

enum class TileType(val id: Int, val description: String, val collidable: Boolean, val damage: Float) {
    GRASS(1, "Green grass", true, 0F),
    DIRT(2, "A little brown dirt", true, 0F),
    STONE(3, "Tough stone", true, 0F);
    /*
    SKY(3, "Empty description", false, 0F),
    LAVA(4, "Dangerous, very hot!", true, 10F),
    CLOUD(5, "Empty description", false, 0F)
    */

    companion object{
        private val tileMap: HashMap<Int, TileType> = HashMap()
        val TILESIZE: Int = 32

        init {
            for(tileType: TileType in TileType.values())
                tileMap.put(tileType.id, tileType)
        }

        fun getTileById(id: Int): TileType? = tileMap[id]
    }
}