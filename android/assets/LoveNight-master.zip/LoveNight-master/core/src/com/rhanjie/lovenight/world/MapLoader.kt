package com.rhanjie.lovenight.world

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.files.FileHandle
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.utils.Json
import com.rhanjie.lovenight.world.tools.MapData
import com.rhanjie.lovenight.world.tools.TileType
import java.util.*

class MapLoader {
    companion object {
        private var JSON: Json = Json()


        fun load(name: String): MapData{
            val file: FileHandle = (Gdx.files).local("$name.map") //TODO: Problem with emulator
            if(!file.exists()) {
                val data = generateRandomMap(name)
                this.save(data.name, data.array)

                return data
            }

            return JSON.fromJson(MapData().javaClass, file.readString())
        }

        fun save(name: String, array: Array<Array<Array<Int?>>>){
            val data = MapData()
            data.name  = name
            data.array = array

            val file: FileHandle = (Gdx.files).local("$name.map") //TODO: Problem with emulator
            file.writeString(JSON.prettyPrint(data), false)
        }

        fun generateRandomMap(name: String): MapData{
            val data = MapData()
            data.name = name
            data.array = Array(3, {Array(AbstractMap.HEIGHT, {arrayOfNulls<Int>(AbstractMap.WIDTH)})})

            val random = Random()

            //TODO: Add better terrain generator
            for(layer: Int in 0 until AbstractMap.LAYERS) {
                for (y: Int in 0 until AbstractMap.HEIGHT) {
                    for (x: Int in 0 until AbstractMap.WIDTH) {
                        data.array[layer][y][x] = 0
                    }
                }
            }

            var grassPos = data.array[0].size/4

            for (x: Int in 0 until AbstractMap.WIDTH) {
                data.array[1][grassPos][x] = (TileType.GRASS).id
                data.array[1][grassPos][x] = (TileType.GRASS).id

                for (y: Int in grassPos+1 until AbstractMap.HEIGHT) {
                    data.array[0][y][x] = (TileType.DIRT).id
                    data.array[1][y][x] = (TileType.DIRT).id

                    /*if(y > grassPos+8) {
                        data.array[0][y][x] = (TileType.GRASS).id
                        data.array[1][y][x] = (TileType.STONE).id
                    }*/
                }

                if(x > 2 && x < data.array[0][0].size-2){
                    if(data.array[1][grassPos][x-2] == (TileType.GRASS).id && data.array[1][grassPos][x-1] == 0 && data.array[1][grassPos][x] == (TileType.GRASS).id){
                        data.array[1][grassPos][x-1] = (TileType.GRASS).id

                        data.array[1][grassPos+1][x-1] = (TileType.DIRT).id
                        data.array[1][grassPos+2][x-1] = (TileType.DIRT).id
                    }
                }

                val randomNumber: Int = random.nextInt(100)
                if(randomNumber < 30)
                    grassPos++
                else if(randomNumber < 60)
                    grassPos--

                if(grassPos > AbstractMap.HEIGHT) grassPos = AbstractMap.HEIGHT-1
                if(grassPos < 0)    grassPos = 1
            }

            return data
        }
    }
}