package com.rhanjie.lovenight.entities

import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.scenes.scene2d.ui.Image

class Player constructor(texture: Texture): Image(texture){
    private val size: Vector2 = Vector2(32F, 64F)
    val speed: Float = 1000F

    init {
        this.setSize(size.x, size.y)
        this.setOrigin(size.x/2, size.y/2)

        this.setPosition(100F, 50F)
    }

    fun update(camera: OrthographicCamera){
        //(camera.position).x = this.x
        //(camera.position).y = this.y

        //camera.update()

        this.debug = true
    }
}