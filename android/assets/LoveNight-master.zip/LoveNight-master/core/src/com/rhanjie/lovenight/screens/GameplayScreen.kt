package com.rhanjie.lovenight.screens

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.InputMultiplexer
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.input.GestureDetector
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.scenes.scene2d.Stage
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.utils.viewport.ScreenViewport
import com.rhanjie.lovenight.MainClass
import com.rhanjie.lovenight.entities.Player
import com.rhanjie.lovenight.input.AndroidController
import com.rhanjie.lovenight.world.Terrain
import com.rhanjie.lovenight.input.MyGestureListener
import com.rhanjie.lovenight.world.AbstractMap
import com.rhanjie.lovenight.world.tools.TileType

class GameplayScreen constructor(game: MainClass): AbstractScreen(game){
    private val camera: OrthographicCamera = OrthographicCamera()
    private val player: Player = Player(Texture("badlogic.jpg"))
    private val gameMap = Terrain("world_1")


    private var backStage: Stage //TODO: New background class
    private val background: Image = Image(Texture("background.png"))
    private val clouds: Image = Image(Texture("clouds.png"))


    private val controller: AndroidController = AndroidController(this.stage)
    private val gestureDetector: GestureDetector = GestureDetector(MyGestureListener(this.player, this.camera, this.gameMap))

    private val inputMultiplexer: InputMultiplexer


    init {
        val spawnPosition = Vector2((AbstractMap.WIDTH * TileType.TILESIZE)/2F, 100F)
        this.initCamera(spawnPosition)

        backStage = Stage(ScreenViewport())
        backStage.addActor(background)
        backStage.addActor(clouds)

        stage.addActor(player)

        inputMultiplexer = InputMultiplexer(this.stage, this.gestureDetector)
        (Gdx.input).inputProcessor = inputMultiplexer
    }

    private fun initCamera(position: Vector2) {
        camera.setToOrtho(false)
        camera.translate(position)
        camera.zoom = 0.4F

        camera.update()
    }

    private fun handleInput() {
        if(controller.isUpPressed)
            gameMap.changeMap("world_2")

        if(controller.isRightPressed)
            player.moveBy(player.speed * (Gdx.graphics).deltaTime, 0F)

        if(controller.isLeftPressed)
            player.moveBy(-player.speed * (Gdx.graphics).deltaTime, 0F)
    }

    private fun update(delta: Float){
        super.render(delta)
        stage.act(delta)

        this.handleInput()
        player.update(this.camera)

        clouds.moveBy(2F, 0F);

        if(clouds.x >= 1920)
            clouds.x = -1920F

        //...
    }

    private fun draw(){
        spriteBatch.begin().apply {

            backStage.draw()
            gameMap.render(camera)
            stage.draw()


            spriteBatch.end()
        }
    }

    override fun render(delta: Float) {
        this.update(delta)

        this.draw()
    }
}